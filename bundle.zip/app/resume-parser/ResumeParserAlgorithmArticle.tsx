export const ResumeParserAlgorithmArticle = () => {
  return <></>;
};
