/* botão stripe
<button
          type="submit"
          className="ml-5 items-center w-18 justify-center w-96 cursor-pointer rounded-2xl text-white flex gap-2 border bg-primary px-3 py-0.5 hover:bg-gray-100 lg:ml-8"
        >
          <span className="whitespace-nowrap font-bold">Gere com</span>
          <Image
            src="assets/stripe.svg"
            alt="Icon"
            width={50}
            height={15}
          />
        </button>
        */

        /* botão de login
        {!session ? (
            <Link
              className="rounded-md px-1.5 py-2 text-white hover:bg-primary focus-visible:bg-gray-100 lg:px-4"
              href="/auth"
            >
              Login
            </Link>
          ) : (
            <SignOut user={session.user} /> // Renderiza o SignOut se o usuário estiver logado
          )}
          */